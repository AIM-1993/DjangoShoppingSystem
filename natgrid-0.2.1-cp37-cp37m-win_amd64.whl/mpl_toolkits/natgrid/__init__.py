__version__ = '0.2'
__doc__ = """
Python interface to NCAR natgrid library.  If installed, used
by matplotlib griddata function. Not intended to be accessed directly by users."""
